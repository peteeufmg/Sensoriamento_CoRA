See RPi/RF24Network/README.md

